//2_1.cpp
#include <iostream>
using namespace std;

int main() {
	cout << "Hello! " << endl;
	cout << "Welcome to C++! " << endl;
	return 0;
}
 