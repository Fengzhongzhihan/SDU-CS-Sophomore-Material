﻿//11_7.cpp
#include <iostream>
using namespace std;
int main() {
	char ch;
	while ((ch = cin.get()) != EOF)
		cout.put(ch);
	return 0;
}
