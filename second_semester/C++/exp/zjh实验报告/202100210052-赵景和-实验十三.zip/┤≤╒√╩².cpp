# include <iostream>
# include <string>

using namespace std;

struct bign
{
    int d[1000];
    int len;

    bign() : d{0}, len(0){}
    bign(string num): bign(){
        len = num.size();
        for(int i=0;i<num.size();++i)
            d[i] = num[len-1 - i] - '0';
    }
    void show(){
    for(int i=len-1;i>=0;i--){
            cout << d[i];
        }cout << endl;
    }

    bool operator<(const bign & rhs){
        if(this->len < rhs.len)
           return true;
        else
        if(this->len > rhs.len)
            return false;
        else
            for(int i = len-1; i >= 0 ; i--){
                if(this->d[i] < rhs.d[i])
                    return true;
                else
                if(this->d[i] > rhs.d[i])
                    return false;
            }
        return false;
    }
    bool operator>(const bign & rhs){
        if(this->len < rhs.len)
           return false;
        else
        if(this->len > rhs.len)
            return true;
        else
            for(int i = len-1; i >= 0 ; i--){
                if(this->d[i] < rhs.d[i])
                    return false;
                else
                if(this->d[i] > rhs.d[i])
                    return true;
            }
        return false;
    }
    bool operator==(const bign & rhs){
        if(this->len == rhs.len){
            for(int i = len-1; i >= 0 ; i--){
                if(this->d[i] != rhs.d[i])
                    return false;
            }
        }
        else
            return false;

        return true;
    }

    bign operator+(const bign & rhs){
        bign c;
        int carry = 0;
        for(int i=0;i<this->len || i<rhs.len;++i){
            int temp = this->d[i] + rhs.d[i] + carry;
            c.d[c.len++]  = temp % 10;
            carry = temp / 10;
        }

        if(carry != 0)
            c.d[c.len++] = carry;

        return c;
    }

    bign operator-(const bign & rhs){
        bign c;
        for(int i=0;i<this->len || i<rhs.len;++i){
            if(this->d[i] < rhs.d[i]){
                this->d[i+1]--;
                this->d[i] += 10;
            }
            c.d[c.len++] = this->d[i] - rhs.d[i];
        }
        while(c.len > 1 && c.d[c.len - 1] == 0)
            c.len--;
        return c;
    }
    bign operator*(int rhs){
        bign c;
        int carry = 0;

        for(int i=0;i<this->len;++i){
            int temp = this->d[i] * rhs + carry;
            c.d[c.len++]  = temp % 10;
            carry = temp / 10;
        }
        while(carry != 0){
            c.d[c.len++] = carry % 10;
            carry /= 10;
        }

        return c;
    }

    pair<bign, int> operator/(int rhs){
        bign c;
        int r = 0;  // 余数
        c.len = this->len;
        for(int i = this->len - 1; i >= 0 ;i--){  // 从高位开始
            r = r*10 + this->d[i];
            if(r < rhs)  // 不够除，该位为0
                c.d[i] = 0;
            else{        // 够除
                c.d[i] = r / rhs;
                r = r % rhs;
            }
        }

        // 去除0
        while(c.len > 1 && c.d[c.len - 1] == 0)
            c.len--;


        return {c, r};
    }
};



int main()
{
    string strnum1, strnum2;
    cin >> strnum1 >> strnum2;
    bign a(strnum1), b(strnum2);
    bign c;
    c = a+b;
    c.show();
    cout << endl;
    c = a-b;
    c.show();
    cout << endl;
    c = a * 10;
    c.show();
    cout << endl;
    auto cc = a / 7;
    cc.first.show();
    cout << cc.second;
}
