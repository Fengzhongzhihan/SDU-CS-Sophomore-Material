#include<iostream>
#include<fstream>
using namespace std;

class QD_CU {
public:
	QD_CU(string name) :Name(name) {}
	string Name;
	int* PC;
};

class QD_ALU {
public:
	QD_ALU(string name) :Name(name) {}
	string Name;
	int AC;
};

class QD_Memory {
public:
	QD_Memory(int name) :Name(name) {}
	int Name;
	int nums[256];
};

class QD_in {
public:
	QD_in(string name) :Name(name) {}
	string Name;
	int shuju;
};

class QD_Out {
public:
	QD_Out(string name) :Name(name) {}
	string Name;
};

class Computer {
public:
	Computer(string name1, string name2, int name3, string name4, string name5) :cu(name1), alu(name2), memory(name3), in(name4), out(name5) {}
	void show1() {
		cout << "������:" << cu.Name << " ������:" << alu.Name << " �洢����С:" << memory.Name << " �����豸:" << in.Name << " ����豸:" << out.Name << endl;
	}
	void show2() {
		cout << "07�ŵ�Ԫ����:" << memory.nums[0] << " 08�ŵ�Ԫ����:" << memory.nums[1] << " �ۼ�������:" << alu.AC << endl;
	}
	void run(string p1_com) {
		int temp1 = 0, temp2 = 0, temp3 = 0, i = 0, cnt[11], j = 0;
		string name;
		char tmp;
		ifstream in;
		in.open("p2_com", ios::in | ios::binary);
		if (in.fail()) {
			cerr << "�ļ��򿪳���!" << endl;
			system("pause");
			exit(1);
		}
		in.read((char*)&cnt, sizeof(cnt));
		while (1) {
			temp1 = cnt[j++];
			temp2 = temp1 / 100;
			if (temp2 == 43)
				break;
			if (temp2 == 10) {
				cin >> temp3;
				memory.nums[i++] = temp3;
			}
			if (temp2 == 20) {
				alu.AC = memory.nums[temp1 - (temp2 * 100) - 7];
			}
			if (temp2 == 30) {
				alu.AC += memory.nums[temp1 - (temp2 * 100) - 7];
			}
			if (temp2 == 21) {
				memory.nums[i++] = alu.AC;
			}
			if (temp2 == 40) {
				break;
			}
			if (temp2 == 11) {
				cout << memory.nums[i - 1] << endl;
			}
			if (temp2 == 0)
				continue;
			if(temp2==32) {
				alu.AC *= memory.nums[temp1 - (temp2 * 100) - 7];
			}
		}
	}
	QD_CU cu;
	QD_ALU alu;
	QD_Memory memory;
	QD_in in;
	QD_Out out;
};
int main() {
	ofstream of("p2_com", ios_base::out | ios_base::binary);
	int nums[11] = { 1007,1008,2007,3208,2109,1109 ,4010,0,0,0,4300 };
	of.write(reinterpret_cast<char*>(nums), 44);
	of.close();
	ifstream iof;
	iof.open("p2_com", ios::in | ios::binary);
	Computer mycomputer1("��оCU1", "��оALU1", 1024, "�����豸1", "����豸1");
	mycomputer1.show1();
	mycomputer1.run("p2_com");
	mycomputer1.show2();
	iof.close();
	return 0;
}
