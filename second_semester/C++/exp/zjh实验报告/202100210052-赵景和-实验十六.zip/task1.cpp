
#include<iostream>
#include<string>
using namespace std;
const int NUM = 5;//定义骑士数量
class Headquarter;//定义阵营类
//定义武士类
class Warrior {
private:
    int id;//表示总的编号
    int selfid;//表示在自己这种武士中的编号
    int health;//生命值
    int attack;//武士攻击力
    string name;//武士类型
    Headquarter* p;
public:
    friend class Headquarter;
    static string names[NUM];//定义武士名字
    static int shunxu[2][NUM];//定义循环产生武士的顺序
    static int warrior_value[NUM];//定义武士元值
    //构造函数进行初始化
    Warrior(Headquarter* p_, int id_, int selfid_, string name_, int health_, int attack_)
    {
        p = p_;
        id = id_;
        selfid = selfid_;
        health = health_;
        attack = attack_;
        name = name_;
    }
};
//对静态变量进行操作必须在类外进行
string Warrior::names[NUM] = { "dragon","ninja","iceman","lion","wolf" };
int Warrior::warrior_value[NUM];//主函数输入各个武士元值
//红蓝双方阵营分别产生武士的顺序
int Warrior::shunxu[2][NUM] = { {2,3,4,1,0},{3,0,1,2,4} };
//定义阵营类
class Headquarter {
private:
    string color;//定义队伍颜色
    int all_number;//该阵营产生武士的数量
    int warrior_number[NUM];//该阵营中各个武士类的数量
    int value_all;//该阵营生命元值
    bool stopped;//控制制造武士的停止
    int makingIndex;//记录现在造第几个武士
    Warrior* p_w[1000];//保存战士
public:
    //初始化阵营
    Headquarter(string color_, int value_all_)
    {
        color = color_;
        value_all = value_all_;
        all_number = 0;
        stopped = false;
        makingIndex = 0;
        for (int i = 0;i < NUM;++i)
            warrior_number[i] = 0;
    }
    //把动态分配内存的战士类全部delete
    ~Headquarter()
    {
        for (int i = 0;i < all_number;++i)
            delete p_w[i];
    }
    //判断是哪方阵营人物
    int getColor()
    {
        if (color == "red")return 0;
        else return 1;
    }
    //制造武士,一次造一个，并根据stopped判断是否还可以造
    int Produce(int nTime)
    {
        if (stopped)return 0;//本阵容找完之后如果其他阵容还在找，可以直接根据这个返回0
        int color_num = getColor();//根据颜色判断是哪个阵营，然后决定使用哪个制造武士顺序
        int count = 0;
        int dx;
        while (count < 5)
        {
            if (makingIndex == 5) makingIndex = 0;
            dx = Warrior::shunxu[color_num][makingIndex];
            if (value_all >= Warrior::warrior_value[dx])
            {
                //找到可以造的了
                break;
            }
            makingIndex++;//如果没找到，就会执行这个，然后找下一个;
            count++;//表示只能找五次，五次都没有找到的话就不能再造了
        }
        makingIndex++;//表示找到可以造的，但是下一次找就得从下一个开始找了，所以自增，因为break所以只能在外部自增
        if (count == 5)
        {
            //表示找不到可以造的武士了
            printf("%03d %s headquarter stops making warriors\n", nTime, color.c_str());
            stopped = true;
            return 0;
        }
        p_w[all_number] = new Warrior(this, all_number + 1, warrior_number[dx] + 1, Warrior::names[dx], 0, 0);
        all_number++;
        warrior_number[dx]++;
        value_all -= Warrior::warrior_value[dx];
        printf("%03d %s %s %d born with strength %d,%d %s in %s headquarter\n", nTime, color.c_str(),
               Warrior::names[dx].c_str(), all_number, Warrior::warrior_value[dx],
               warrior_number[dx], Warrior::names[dx].c_str(), color.c_str());
        return 1;
    }
};
int main()
{
    int n;
    cin >> n;
    int nn = n;
    while (n--)
    {
        cout << "Case:" << nn - n << endl;
        int m;//初始生命元
        cin >> m;
        Headquarter R_H("red", m);//初始化阵容类
        Headquarter B_H("blue", m);
        for (int i = 0;i < NUM;++i)
            cin >> Warrior::warrior_value[i];
        int nTime = 0;
        while (true)
        {
            int tmp1 = R_H.Produce(nTime);
            int tmp2 = B_H.Produce(nTime);
            if (tmp1 == 0 && tmp2 == 0)break;
            nTime++;
        }
    }
    return 0;
}
