main.cpp文件中的
standard_test();// 标准测试  需要包含  ExternalSorting_StandardTest.h  文件，但是考虑到文件路径不同，你需要将文件名中的data1前的路径改为你的路径
用于测试给定数据
random_test();// 随机测试   需要包含  ExternalSorting_StandardTest.h  文件，会在指定路径文件夹下生成数据，你需要生成random_data1文件夹并将前边路径修改为你的路径
用于生成随机数据进行测试

LoserTree.h
虽然实验要求包含LoserTree.h和LoserTree.cpp文件，但是我并没有这么做，而是合并到了一个文件LoserTree.h中，
原因是我觉得模板类并不能分文件声明和实现，据我参考的文件也是如此，具体见实验报告
或许确实有好方法可以解决这个问题，但是请原谅我孤陋寡闻，没搜到……，我搜到的文章告诉我不能这样做